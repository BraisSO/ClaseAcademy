package com.example.backmusica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackmusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackmusicaApplication.class, args);
	}

}
