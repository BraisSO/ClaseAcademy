export class Disco{
     id:number=0;
     nombre:string="";
     año:number=0;
     banda={
          id:0,
          nombre:""
     }
}