export class Banda{
     id:number=0;
     nombre:string="";
     albums={
          id:0,
          nombre:"",
          año:0};
}