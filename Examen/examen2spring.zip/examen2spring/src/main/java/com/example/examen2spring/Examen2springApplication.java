package com.example.examen2spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen2springApplication {

	public static void main(String[] args) {
		SpringApplication.run(Examen2springApplication.class, args);
	}

}
