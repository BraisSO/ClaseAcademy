package com.example.examen2spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen2springApplicationTests {

	@Test
	void contextLoads() {
	}

}
