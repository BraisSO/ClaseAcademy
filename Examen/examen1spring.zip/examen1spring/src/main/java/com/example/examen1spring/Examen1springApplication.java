package com.example.examen1spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen1springApplication {

	public static void main(String[] args) {
		SpringApplication.run(Examen1springApplication.class, args);
	}

}
