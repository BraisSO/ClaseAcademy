package com.example.examen1spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen1springApplicationTests {

	@Test
	void contextLoads() {
	}

}
